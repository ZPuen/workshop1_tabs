export interface Beverage{//export คือ ส่งออก
    menu_code: String;
    menu_name: String;
    price: number;
    img: String;
}